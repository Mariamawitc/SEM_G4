# SEM_G4
A review on common refactoring methods
